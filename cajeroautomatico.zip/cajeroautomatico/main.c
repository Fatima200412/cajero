#include <stdio.h>
#include <stdlib.h>
#include"funciones.h"


int main()
{
    //variables del programa
    int opc, v;
    float saldo=leer(),depositar, retirar;
    //se verifica el PIN
    if(!acceso()){
        printf("SE HA ALCANZADO EL LIMITE DE INTENTOS");
        return 1;
    }

    do{
        puts("\t -------BIENVENIDO!------");
        puts("\t ---CAJERO AUTOMATICO --- \n");
    //menu de opciones disponibles
        puts(" SELECCIONE UNA OPERACION \n");
        puts("1)CONSULTAR SALDO \n");
        puts("2)DEPOSITAR DINERO \n");
        puts("3)RETIRAR DINERO \n");
        puts("4)SALIR DEL CAJERO\n");
        scanf("%d",&opc);

   //estructura que maneja la opcion seleccionada
        switch (opc){
        case 1:
            consultar(saldo);
            break;

        case 2:
            printf(" INGRESA LA CANTIDAD A DEPOSITAR:");
            scanf("%f",&depositar);
            v = valida(depositar);
            while (v!=0){
                scanf("%f",&depositar);
                v=valida(depositar);
            }
            saldo = saldo+depositar;
            printf("\n \t  HAS AGREGADO $ %f PESOS A TU CUENTA \t \n TU NUEVO SALDO ES DE $ %f PESOS \n",depositar, saldo);
            guardarsaldo(saldo);
            break;

        case 3:
            printf(" INGRESA LA CANTIDAD A RETIRAR:");
            scanf("%f",&retirar);
            v = valida(retirar);
            while (v!=0){
                scanf("%f",&retirar);
                v=valida(retirar);
            }
            if (retirar> saldo){
                printf(" ERROR! TU SALDO ES INSUFICIENTE \n");
            }
            else{
            saldo = saldo- retirar;
            printf("\n \t HAS RETIRADO $ %f PESOS DE TU CUENTA \t \n TU NUEVO SALDO ES DE $ %f PESOS \n",retirar, saldo);
            guardarsaldo(saldo);
            }
            break;

        case 4:
            puts("\n \t GRACIAS POR USAR EL CAJERO \n \t HASTA LUEGO! \n");
            guardarsaldo(saldo);
            break;
        default:
            puts(" \n OPCION NO VALIDA \n INTENTA NUEVAMENTE  \n ");



        }

    }
    while(opc!=4);



    return 0;
}
