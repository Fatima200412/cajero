#include <stdio.h>
#define PIN 1234
#define intentos 3
#define archivosaldo "saldo.txt"

///funciones
//fun para consultar saldo
void consultar(float saldo){
    printf("TU SALDO ES DE $ %f PESOS \n",saldo);
}

//fun para depositar o retirar saldo
int valida(float x) {
    if (x > 0) {
        printf("REALIZANDO OPERACION...\n");
        return 0;
    }
    else if (x == 0) {
        printf("NO ES POSIBLE REALIZAR ESTA OPERACION, INTENTA NUEVAMENTE:.\n");
        return 1;
    }
    else {
        printf("CANTIDAD NO VALIDA.\n");
        return 101;
    }
}

//fun verificar PIN
int acceso() {
    int piningresado;
    for (int i = 0; i < intentos; i++) {
        printf("POR FAVOR INGRESA TU PIN: ");
        scanf("%d", &piningresado);
        if (piningresado == PIN) {
            printf("PIN CORRECTO! \n");
            return 1;
        } else {
            printf("PIN INCORRECTO\n");
        }
    }
    return 0;
}
//fun leer archivo d texto
float leer ( ){
    FILE *archivo = fopen( archivosaldo,"r");
    float saldo = 1000;
    if (archivo != NULL){
        fscanf(archivo,"%f",&saldo);
        fclose(archivo);
    }
    return saldo;
}
//fun guardar archivo d texto
void guardarsaldo(float saldo){
FILE *archivo = fopen (archivosaldo,"w");
if( archivo!= NULL){
    fprintf(archivo, "%f", saldo);
    fclose (archivo);
}
else{
    printf("error al guardar saldo");
}
}


