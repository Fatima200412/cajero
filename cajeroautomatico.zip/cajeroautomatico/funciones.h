#ifndef FUNCIONES_H_INCLUDED
#define FUNCIONES_H_INCLUDED

#define PIN 1234
#define intentos 3
#define archivosaldo "saldo.txt"

//  funci�n consultar
void consultar(float saldo);

//  funci�n valida
int valida(float x);

// funci�n acceso
int acceso(void);

// funci�n leer
float leer(void);

//funci�n guardarsaldo
void guardarsaldo(float saldo);

#endif // FUNCIONES_H_INCLUDED

